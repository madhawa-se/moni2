<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['domain'] = "bridesandgrooms.lk";
$config['company_name'] = "Brides & Grooms";