        <header>
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                        <style>
                            .img2{
                                vertical-align: middle;
                                margin-top: -12px;
                            }
                            .well8{
                                padding: 0px;
                            }

                        </style>
                        <a href="<?php echo base_url() ?>"><img height="80px" src="<?php echo base_url() ?>images/logo5.png" class="img2"></a>

                    </div>
                    <div class="col-sm-6 hidden-xs">

                    </div>
                </div>
            </div>
        </header>
