<style>
    .well9 {


        margin-bottom: 0px;
        background-color: #fff;
        color: #000;

    }
    footer,.footer{
        text-align: center;
    }

</style>
<div class="well9">
    <div class="container">
        <br>
        <a href="">About Us</a> | <a href="">Contact Us</a>
        <a href="">Privacy Policy</a> | <a href="">Qatar</a>
        <a href="">Pay Now</a> | <a href="">Post Success Story</a> | <a href="">Terms and Conditions</a>
        | <a href="">Popular Matrimony Search</a> | <a href="">Events</a><br>


    </div>


    <!--footer-->

    <footer class="footer">

        <div class="container">

            <ul class="social-icon animate">
                <font color="black"> <b>Follow Us : </b> </font>        <li><a style="background-color: #295396;" href="#" title="facebook" target="_blank"><i class="fa fa-facebook"></i></a></li> <!-- change the link to social page and edit title-->
                <li><a style="background-color:#1DA1F3;" href="#" title="twitter" target="_blank"><i class="fa fa-twitter"></i></a></li>
                <li><a style="background-color:#DF4A32;" href="#" title="google plus" target="_blank"><i class="fa fa-google-plus"></i></a></li>
            </ul>
        </div>
    </footer>
</div>