<?php

class Error_404 extends CI_Controller{
    public function index(){
        echo 'hello';
        //$this->load->view("custom_errors/error_404");
    }
}
