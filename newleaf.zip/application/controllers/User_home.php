<?php

class User_home extends My_Controller {
    
}
