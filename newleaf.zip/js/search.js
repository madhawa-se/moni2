var app = angular.module('myapp', ['ngRoute']);

app.controller('searchCTRL', function ($scope, $http, $filter) {
    
});
