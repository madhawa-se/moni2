var app = angular.module('myapp', []);

app.controller('formController', function ($scope) {

    $scope.x=10;
    $scope.countrycode="";
    $scope.regex = 'm';
    $scope.formsubmitted = false;
    $scope.submitForm = function (isValid) {

        if (isValid) {
           // alert('our form is amazing');
           return true;
        }else{
            $scope.formsubmitted=true;
            //alert(' form is invalid');
            console.log($scope.regform.$error);
        }

    };
    $scope.updateCountry=function(){
        var country = $('#livein :selected');
        var countryName=country.text();
        $scope.countrycode=("+"+country.data("country_code"));
    };

});
